import ast
import operator
import math

OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
}

FUNCS = {
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "sqrt": math.sqrt,
    "log": math.log,
    "exp": math.exp,
}

CONSTS = {
    "pi": math.pi,
    "e": math.e,
}

def looks_like_math(expr):
  
    expr = expr.strip()
    if any(c.isdigit() for c in expr):
        return True
    if any(op in expr for op in "+-*/^"):
        return True
    math_funcs = ("sin", "cos", "tan", "sqrt", "log", "exp")
    if any(f in expr for f in math_funcs):
        return True
    if any(c in expr for c in ("pi", "e")):
        return True
    return False

def evaluate_math(expr):
    try:
        node = ast.parse(expr, mode="eval")
        return _eval(node.body)
    except Exception:
        return None

def _eval(node):
    if isinstance(node, ast.Constant):
        return node.value

    if isinstance(node, ast.Name):
        if node.id in CONSTS:
            return CONSTS[node.id]
        raise ValueError("Unknown constant")

    if isinstance(node, ast.BinOp):
        return OPS[type(node.op)](_eval(node.left), _eval(node.right))

    if isinstance(node, ast.UnaryOp):
        return OPS[type(node.op)](_eval(node.operand))

    if isinstance(node, ast.Call):
        if not isinstance(node.func, ast.Name):
            raise ValueError("Invalid function")
        fname = node.func.id
        if fname not in FUNCS:
            raise ValueError("Function not allowed")
        args = [_eval(a) for a in node.args]
        return FUNCS[fname](*args)

    raise ValueError("Invalid math expression")