import re

ACTION_KEYWORDS = ("study", "work", "play", "rest", "sleep")

def extract_actions(text):
    t = text.lower()
    actions = []
    for kw in ACTION_KEYWORDS:
        matches = re.findall(r"\b" + kw + r"\b", t)
        for m in matches:
            actions.append(m)
    return list(set(actions))