# Core-A
# v0.3.1

import sys, os, time, traceback
sys.path.append(os.path.dirname(__file__))

import memory
import smalltalk
import reasoning
import math_eval
import actions
import evaluation
import world_model

def aurum_intro():
    print("Aurum • Initializing...\n")
    for step in [
        "Booting memory core",
        "Loading reasoning engine",
        "Preparing smalltalk module",
        "Starting math evaluator",
        "Activating world simulator",
        "Loading action evaluation",
        "Finalizing startup"
    ]:
        print(f"{step}...", end="", flush=True)
        time.sleep(0.25)
        print(" done")
    print("\nAurum online.\n")

def apply_delta(state, delta):
    new_state = state.copy()
    for k, v in delta.items():
        new_state[k] = new_state.get(k, 0) + v
    return new_state

def main():
    mem = memory.load_memory()
    rules = reasoning.load_rules()
    state = world_model.load_state()
    last_explanation = None

    aurum_intro()

    while True:
        try:
            user = input("> ").strip()
            if not user:
                continue
            lower = user.lower()

            if lower in ("exit", "quit"):
                memory.save_memory(mem)
                reasoning.save_rules(rules)
                world_model.save_state(state)
                print("Aurum shutting down.")
                break

            if lower in ("why", "explain"):
                print(last_explanation or "Nothing to explain yet.")
                continue

            # Smalltalk
            talk = smalltalk.respond(user)
            if talk:
                print(talk)
                continue

            # Memory query first
            facts = memory.query(mem, user)
            if facts:
                for f in facts:
                    print(f"{f['fact']} (confidence {f['confidence']:.2f})")
                continue

            # Learn new fact if user provides declarative statement
            if user.endswith("."):
                memory.store_fact(mem, user, user)
                memory.save_memory(mem)
                print("✅ Got it, I've remembered that.")
                continue

            # Math evaluation after memory and facts
            if math_eval.looks_like_math(user):
                result = math_eval.evaluate_math(user)
                print("🧮", result if result is not None else "Invalid math expression")
                continue

            # Actions
            acts = actions.extract_actions(user)
            if acts:
                best_action, best_score = None, -1e9
                explanation = []

                for act in acts:
                    delta = world_model.simulate(state, act)
                    if not delta:
                        explanation.append(f"Cannot simulate '{act}'.")
                        continue

                    imagined = world_model.clamp_state(apply_delta(state, delta))
                    score = evaluation.score(imagined)

                    explanation.append(f"\nIf '{act}':")
                    for k, v in delta.items():
                        explanation.append(f" {k}: {v:+}")
                    explanation.append(f" Score: {score}")

                    if score > best_score:
                        best_score = score
                        best_action = act

                if best_action:
                    explanation.append(f"\nChosen action: {best_action}")
                    last_explanation = "\n".join(explanation)
                    print(last_explanation)

                    state = world_model.clamp_state(
                        apply_delta(state, world_model.simulate(state, best_action))
                    )
                    world_model.save_state(state)
                else:
                    print("\n".join(explanation))

                continue

            # Rules
            rule = reasoning.apply_rules(rules, user)
            if rule:
                print(rule)
                continue

            # No answer yet
            print("I don't know that yet.")

        # Runtime errors
        except (ValueError, KeyError, TypeError):
            print("⚠️ Internal error (see log file).")
            with open("aurum_error.log", "a", encoding="utf-8") as f:
                traceback.print_exc(file=f)

        # System exit / Ctrl+C
        except (KeyboardInterrupt, SystemExit):
            print("\nAurum shutting down.")
            break

if __name__ == "__main__":
    main()