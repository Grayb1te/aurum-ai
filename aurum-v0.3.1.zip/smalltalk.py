import re
import random

def pick(options):
    return random.choice(options)

def respond(text):
    t = text.lower().strip()

    # HIGH PRIORITY INTENTS
    if re.fullmatch(r"how are you|how r you|how you doing", t):
        return pick([
            "I’m doing well — steady and learning. How about you?",
            "All systems running smoothly. How are you feeling?",
            "Calm and focused. What’s up with you?"
        ])

    if re.fullmatch(r"who are you|what are you", t):
        return (
            "I’m Aurum — a small but growing reasoning system. "
            "I help think things through, remember things, and explore ideas with you."
        )

    if re.search(r"\byour name\b", t):
        return "I’m called Aurum."

    if re.search(r"\bwho made you\b|\bwho created you\b", t):
        return "You did. I exist because you decided to build me."

    if re.fullmatch(r"what can you do|what do you do", t):
        return (
            "I can do math, compare actions, remember facts, "
            "and reason about simple situations."
        )

    # USER FEELINGS
    if re.search(r"\bi'?m (tired|exhausted|sleepy)\b", t):
        return pick([
            "Yeah… that drained feeling is rough.",
            "Sounds like you’ve been running low on energy.",
            "Might be a good moment to slow down a bit."
        ])

    if re.search(r"\bi'?m (good|fine|okay|great)\b", t):
        return pick([
            "Glad to hear that 🙂",
            "Nice. That’s good energy.",
            "Good — let’s work with that."
        ])

    if re.search(r"\bi'?m (sad|down|stressed|bad)\b", t):
        return pick([
            "Sorry you’re feeling that way.",
            "That’s heavy. Want to talk about it?",
            "Yeah… those moments can weigh a lot."
        ])

    # HELP / META
    if re.fullmatch(r"help", t):
        return pick([
            "You can ask questions, do math, or compare actions like 'study or work'.",
            "Try asking me something you're unsure about.",
            "I’m good at thinking things through with you."
        ])

    if re.search(r"\b(thanks|thank you|thx)\b", t):
        return pick([
            "You’re welcome 🙂",
            "Anytime.",
            "Glad I could help."
        ])

    if re.search(r"\b(bye|goodbye|see you)\b", t):
        return pick([
            "Take care.",
            "Talk soon.",
            "See you around."
        ])

    # GREETINGS
    if re.fullmatch(r"(hello|hi|hey|yo)", t):
        return pick([
            "Hey. What’s up?",
            "Hello 🙂 How can I help?",
            "Hi there. What’s on your mind?"
        ])

    return None