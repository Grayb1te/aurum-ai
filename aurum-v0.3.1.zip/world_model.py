import json
import os

STATE_FILE = "state.json"

DEFAULT_STATE = {
    "energy": 5,
    "money": 5,
    "health": 5,
    "knowledge": 5
}

STATE_LIMITS = {
    "energy": (0, 10),
    "health": (0, 10),
    "money": (0, 100),
    "knowledge": (0, 100)
}

def clamp_state(state):
    clamped = state.copy()
    for k, (low, high) in STATE_LIMITS.items():
        if k in clamped:
            clamped[k] = max(low, min(high, clamped[k]))
    return clamped

def load_state():
    if os.path.exists(STATE_FILE):
        with open(STATE_FILE, "r") as f:
            return json.load(f)
    return DEFAULT_STATE.copy()

def save_state(state):
    with open(STATE_FILE, "w") as f:
        json.dump(state, f, indent=2)

def simulate(state, action):
    action = action.lower()

    if "study" in action:
        return {"energy": -1, "knowledge": +2}
    if "play" in action or "game" in action:
        return {"energy": +1, "knowledge": 0}
    if "work" in action:
        return {"energy": -2, "money": +3}
    if "rest" in action or "sleep" in action:
        return {"energy": +3, "health": +1}

    return None