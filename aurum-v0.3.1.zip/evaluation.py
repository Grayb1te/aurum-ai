WEIGHTS = {
    "energy": 1,
    "money": 2,
    "health": 3,
    "knowledge": 4
}

def score(state):
    total = 0
    for k, w in WEIGHTS.items():
        total += state.get(k, 0) * w
    return total

def explain_delta(delta):
    explanations = []
    for k, change in delta.items():
        weight = WEIGHTS.get(k, 0)
        impact = change * weight
        sign = "+" if change > 0 else ""
        explanations.append(f"{k} {sign}{change} × weight {weight} → impact {impact}")
    return explanations